
  
    document.getElementById("form").onsubmit = function(){
        var name = document.getElementById("name").value;
        var email = document.getElementById("email").value;
        var site_name = document.getElementById("site-name").value;
        var site_url = document.getElementById("site-url").value;

        document.getElementById("company-name").innerHTML = name;
        document.getElementById("result-section").style.display = "block";

        var site_name_len = document.getElementsByClassName('site-name').length;
        var site_url_len = document.getElementsByClassName('site-url').length;
        var email_len = document.getElementsByClassName('email-text').length;

        for(var i = 0; i<site_name_len; i++){
          document.getElementsByClassName('site-name')[i].innerHTML = site_name;
        }

        for(var k = 0; k<site_url_len; k++){
            document.getElementsByClassName('site-url')[k].innerHTML = site_url;
        }

        for(var j = 0; j<email_len; j++){
            document.getElementsByClassName('email-text')[j].innerHTML = email;
        }

        return false;
    }


    function policy_copy(){
        var text = document.getElementById("policy").innerHTML.replace(/class="email-text"/g,"").replace(/id="company-name"/g,"").replace(/class="site-name"/g,"").replace(/class="site-url"/g,"");
        copy(text);
    }

    function contact_copy(){
        var text = document.getElementById("contact-us").innerHTML.replace(/class="email-text"/g,"");
        copy(text);
    }
    
    function about_copy(){
        var text = document.getElementById("about-us").innerHTML.replace(/class="email-text"/g,"");
        copy(text);
    }

    function dmca_copy(){
        var text = document.getElementById("dmca").innerHTML.replace(/class="email-text"/g,"");
        copy(text);
    }

    function copy(text){
        var input = document.createElement("input");
        input.value = text;
        document.body.append(input);
        input.select();
        document.execCommand('copy');
        document.body.removeChild(input);
    }













  